package jobs;

public enum TopicDetails {

    user_activity_demographics,
    consumer_activity
}
